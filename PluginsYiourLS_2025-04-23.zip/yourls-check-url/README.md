yourls-check-url [![Listed in Awesome YOURLS!](https://img.shields.io/badge/Awesome-YOURLS-C5A3BE)](https://github.com/YOURLS/awesome-yourls/)
================

A plugin for YOURLS that checks the reachability of a URL before creating the short link
