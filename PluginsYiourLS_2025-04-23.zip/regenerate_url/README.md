
Allow Forward Slashes in Short URLs
---------------------------------------------

- Plugin Name: Allow Forward Slashes in Short URLs
- Plugin URI: http://williambargent.co.uk
- Description: Allow Forward Slashes in Short URLs
- Version: 1.0
- Author: William Bargent


This plugin will allow forward slashes `/` in keywords when shortening URLS with YOURLS.

*NOTE This plugin will not work with URL Forwarding plugins active. Deactivate before activating this plugin.

###Installation

1. Download these file as a .zip.
2. Extract the three files and copy them into a `New Folder` called `forward-slash-in-urls`.
3. Copy this folder.
4. Paste this folder in your YOURLs directory under `users/plugins/`.
5. Go to your plugin manager and click `Activate`.
