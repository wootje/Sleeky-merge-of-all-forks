<html>
<body>
<?php 
    require_once $_SERVER['DOCUMENT_ROOT'].'/includes/load-yourls.php' ;
    include 'pages/linkslist.inc.php';
?>
</body>
</html>
